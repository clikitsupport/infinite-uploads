<?php return array('dependencies' => array('react-jsx-runtime'), 'version' => '4dd50626eed3ac988f73');
